﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheExpertSystem_Quinn
{

    // *************************************************************
    // Application:     The Expert System
    // Author:          Quinn, Luke
    // Description:     An application that has a conversation with the user
    //                  about gaining interest in a savings account over a span of time
    // Date Created:    02/05/2020
    // Date Revised:    02/09/2020
    // *************************************************************
    class Program
    {
        static void Main(string[] args)
        {
            //
            // screen configurations
            // set screen colors for the theme
            // 
            ConsoleColor openingClosingScreenBackground = ConsoleColor.DarkCyan;
            ConsoleColor openingClosingScreenForeground = ConsoleColor.Black;
            

            //
            // constants
            //

            
            const double INTEREST_RATE_LOW = 0.001;
            const double INTEREST_RATE_MID = 0.0025;
            const double INTEREST_RATE_HIGH = 0.0075;


            //
            // variables
            //
            string userName;
            string bankChoice;            
            string userResponse;
            string balanceSelect;
            double principleBalance;

            
            double growthYears;
            
            double yearlyInterest;
            
            

            bool validResponse;


            
            //      **********************
            //      *   Opening Screen   *
            //      **********************
                        
            Console.CursorVisible = false;
            Console.BackgroundColor = openingClosingScreenBackground;
            Console.ForegroundColor = openingClosingScreenForeground;
            
            Console.Clear();                              

            Console.WriteLine();
            Console.WriteLine("\t\tThe Savings Growth Guru");
            Console.WriteLine();
            Console.WriteLine("\tPress any key to continue.");
            Console.ReadKey();

            Console.Clear();



            Console.CursorVisible = true;
            Console.BackgroundColor = openingClosingScreenBackground;
            Console.ForegroundColor = openingClosingScreenForeground;

            Console.WriteLine("Hello there! This is an application to show you what your \nfuture blances could be within a savings account.");
            Console.WriteLine();
            Console.Write("If you don't mind, please tell me your name: ");
            userName = Console.ReadLine();

            Console.Clear();

            Console.WriteLine($"Very nice to meet you {userName}!\nWould you like to see how your money will grow in a savings account?(yes/no): ");
            userResponse = Console.ReadLine();
            Console.Clear();


            if (userResponse == "yes")
            {
                //
                // display header
                //
                Console.WriteLine();
                Console.WriteLine("\t\tAccount Information");

                Console.WriteLine();
                Console.WriteLine();

                //user info: bank, what kind of balance are they keeping, how many years do they want to factor for?
                //

                Console.WriteLine($"Awesome {userName}! Let me pick your brain for some account information");
                Console.Write("What is the name of the bank / credit union are you a current member of?:\n ");
                bankChoice = Console.ReadLine();
                

                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine("How many years would you like me to factor for the growth calculator?(1-50): ");
                growthYears = double.Parse(Console.ReadLine());
                                 
               

                Console.WriteLine();
                Console.WriteLine($"Thank you for sharing that {userName}! Let's see what we can do for you over\n a total of {growthYears} years , eh!");
                Console.WriteLine("Press any key to continue: ");
                Console.ReadKey();
                
                Console.Clear();                            

                do
                {
                    //  *************************
                    //  Chosing proper account  *
                    //  *************************

                    validResponse = true;

                    Console.WriteLine();
                    Console.WriteLine("\t\tChosing Your Account");

                    Console.WriteLine();
                    Console.WriteLine();

                    Console.Write("What is the total balance (USD) we will be managing in this savings account?");
                    Console.WriteLine();
                    Console.WriteLine($"\"Alpha\" {1:C} to {5000:C} \n\"Bravo\" {5000:C} to {25000:C} \n\"Charlie\" {25000:C} PLUS?");
                    Console.WriteLine();
                    Console.Write("Enter amount balance selector\nAlpha\nBravo\nCharlie: ");
                    balanceSelect = Console.ReadLine();
                    

                    if (balanceSelect != "Alpha" && balanceSelect != "Bravo" && balanceSelect != "Charlie")
                    {
                        validResponse = false;

                        Console.WriteLine();
                        Console.WriteLine("OPE! It appears you entered an invalid selection. Please reenter your total balance selection.");
                        Console.WriteLine();
                        Console.WriteLine("Please press any key to continue!");
                        Console.ReadKey();
                        Console.Clear();
                    }                             



                } while (!validResponse);

                switch (balanceSelect)
                {
                    case "Alpha":
                        yearlyInterest = INTEREST_RATE_LOW;
                        break;

                    case "Bravo":
                        yearlyInterest = INTEREST_RATE_MID;
                        break;


                    case "Charlie":
                        yearlyInterest = INTEREST_RATE_HIGH;
                        break;

                    default:
                        yearlyInterest = 0;
                        break;
                }
                
                
                Console.WriteLine();

                Console.WriteLine($"Interest for you, {userName} will obviously be determined by the balance\nplease enter balance now: ");
                userResponse = Console.ReadLine();
                principleBalance = Convert.ToDouble(userResponse);
                               
                Console.WriteLine();
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();

                Console.Clear();

                Console.WriteLine();
                Console.WriteLine($"\t\tGrowth for {userName}");
               
                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine($"Based on what you have told me {userName}, with the principle balance\n" +
                    $"of {principleBalance:C}, that qualifies you for rate of {yearlyInterest:P} APY");
                
                Console.WriteLine();
                Console.WriteLine();

                
                               
                Console.WriteLine("Press any key to see how much that adds up to over time!: ");
                Console.ReadKey();

                Console.Clear();

                //  ***********************
                //  Displaying the Table  *
                //  ***********************

                Console.WriteLine();
                Console.WriteLine("\t\t Savings Over the Years");
                Console.WriteLine();

                DateTime myValue = DateTime.Now;
                
                Console.WriteLine("Year".PadLeft(5) +
                    "Current Balance".PadLeft(20)                  
                    );

                double yearlyInterestYield;
                double currentBalance = principleBalance;
                double totalInterest;
                                             
                yearlyInterestYield = currentBalance * yearlyInterest;
                                                             
                for (int year = 1; year <= growthYears; year++)                
                {
                    
                    double factor = (currentBalance * (Math.Pow(1.0 + yearlyInterest, year)));
                    currentBalance = factor;
                    Console.WriteLine(year.ToString().PadLeft(5) +
                        currentBalance.ToString("C2").PadLeft(20)                     
                        );

                    if(year == growthYears)
                    {
                        totalInterest = currentBalance - principleBalance;
                        Console.WriteLine();
                        Console.WriteLine("With an ending date of {0}", myValue.AddYears(Convert.ToInt32(growthYears)).ToShortDateString());
                        Console.WriteLine($"Total interest made is {totalInterest:C}");



                        //*****************
                        //  closing       *
                        //*****************

                        Console.WriteLine("Press any key to continue!:");
                        Console.ReadKey();
                        Console.Clear();

                        Console.WriteLine();
                        Console.WriteLine();

                        Console.WriteLine("Thank you for using Savings Growth Guru! Tell your friends!\nPress any key to EXIT:");
                        Console.ReadKey();
                        Console.Clear();
                        
                    }


                           


                    

                }

                
                
            }

            //User isn't interested in the app. Thank them and close app.
            else 
            {
                Console.CursorVisible = false;
                Console.BackgroundColor = openingClosingScreenBackground;
                Console.ForegroundColor = openingClosingScreenForeground;

                Console.Clear();

                Console.WriteLine("Sorry to hear that you're not interested. We appreciate your time regardless!");
                Console.WriteLine();
                Console.WriteLine("The Savings Growth Guru");
                Console.WriteLine();
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();

                Console.Clear();

            }



            






                   


        }
    }
}
